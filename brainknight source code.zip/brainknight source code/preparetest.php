<?php
	session_start ( );
	include "data.php";
	$dt = date ( 'Y-m-d' );
	$tq = 0;
	$numofquestionsavailabel = 0;
	///////////////////////////SETTING THE answer_sheet////////////////////////////////
	if ((!(isset ($_SESSION[ 'testOpened' ] ))) && (!(isset ($_SESSION[ 'unfinishedtest' ] )))){
		//if ( $_SESSION [ 'testOpened' ] != 1 ) {
		  //echo ( "Inside" );
		$_SESSION [ 'testOpened' ] = 1;
		$uid = $_SESSION [ "uid" ];
		$tid = $_REQUEST [ "tid" ];
		$uniquequestion = $_REQUEST['uniquest'];//display unique questions for each user if 1
		$tq = $_REQUEST ['tq'];
		$_SESSION ['tq'] = $tq; //total questions in test
		$_SESSION ['qd'] = 0; //questions displayed in front of user QuestionsNotDisplayed
		$_SESSION [ 'tid' ] = $tid;
		mysql_select_db ( $database, $data );
		
		if ( $uniquequestion == 1 ) //if uniquequestion==1 show unique questions for each user
			$sqlchk = "SELECT *, questions.q_id as ques_id FROM questions LEFT JOIN answer_sheet ON questions.q_id = answer_sheet.q_id WHERE answer_sheet.q_id IS NULL ORDER BY RAND() LIMIT 0, $tq;";
		else {
			if ( ! isset ( $_SESSION ['unfinishedtest'] ) ) //if not unfinished test for repeated question user than get 30 random repeated questions from db
				$sqlchk = "SELECT *, questions.q_id as ques_id FROM questions ORDER BY RAND() LIMIT 0, $tq;";
			else { //if unfinished test for repeated user question
				$sqlchk = "SELECT *, questions.q_id as ques_id FROM questions INNER JOIN answer_sheet ON questions.q_id = answer_sheet.q_id WHERE answer_sheet.user_id = $uid AND answer_sheet.test_id = $tid AND answer_sheet.q_shown = 0";
			}
		}
		
		mysql_select_db ( $database, $data );
		$result = mysql_query ( $sqlchk );
		$numofquestionsavailabel = mysql_num_rows ( $result );
		if ( $numofquestionsavailabel < $tq ) {//check that db contains enought questions to be displayed
			echo ( "<h2>Questions not available Please Contact Administrator</h2>" );
			header ( "location: questionsnotfound.php" );
		}
		//else { //if db contains enough questions than create test
		  //echo ( "<table align='center' width='75%'>");
		  while ( $row = mysql_fetch_object ( $result ) ) {
			  $sqlIns = "INSERT INTO answer_sheet ( test_id, user_id, test_date, q_id, q_ans1, q_ans2, q_ans3, q_ans4, q_ans5 ) VALUES ( $tid, $uid, '$dt', $row->ques_id, 0, 0, 0, 0, 0 )";
			  mysql_query ( $sqlIns );
		  }
		//}
	}
//	if( ! $numofquestionsavailabel > $tq ) { 
		if ( isset ($_SESSION['unfinishedtest'] ) ) { //executed if users is loged in again for an unfinished test
			if ( $_SESSION['unfinishedtest'] == 1 ) {
			  $uid = $_SESSION [ "uid" ];
			  $tid = $_REQUEST [ "tid" ];
			  $tq = $_REQUEST ['tq'];
			  $_SESSION ['tq'] = $tq; //total questions in test
			  $_SESSION ['qd'] = 0; //questions displayed in front of user QuestionsNotDisplayed
			  $_SESSION [ 'tid' ] = $tid;
			  //mysql_select_db ( $database, $data );
			  //$sqlufq = "SELECT * FROM answer_sheet INNER JOIN questions ON answer_sheet.q_id = questions.q_id WHERE test_date = CURDATE() AND user_id = $uid AND q_shown = 0;";
			  //$resultufq = mysql_query ( $sqlufq );
			  
			}
		}
		//disabling current user for taking more tests and storing date of test
		mysql_select_db ( $database, $data );
		$sqldisableuser = "UPDATE user SET tested = 1 WHERE user_id = " . $_SESSION['uid'];
		mysql_query ( $sqldisableuser );
		  mysql_select_db ( $database, $data );
		  $sqlInsert = "UPDATE user SET login_date = '$dt' WHERE user_id = " . $_SESSION ['uid'];
		  //echo ( $sqlInsert );
		  mysql_query ( $sqlInsert );
		
			//////////////////////////////////////
	
		////////////////////////////////////////////////////////////////////////////////////
		//header ( "Location:TestPaper.php" );
//	}
?>
	<script language="javascript">
		setTimeout ( "location.href='TestPaper.php'", 00 );
	</script>