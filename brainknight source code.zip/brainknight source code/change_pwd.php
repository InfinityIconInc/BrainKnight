<?php
	session_start ( );
	if ( ! isset ( $_SESSION ['uid' ] ) )
		header("location:index.php");

	if($_SESSION['uid']=="")
	{
		header("location:index.php");
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css"/>
<title>Change Password</title>
<script type="text/javascript">
function checkForm(form1) {
	var ok = true;
	if(document.form1.txtPwd.value == "") { 
	  alert("Error: Password cannot be blank!"); 
	  document.form1.txtPwd.focus();
	  ok = false;
	} 
	if(document.form1.txtRPwd.value == "") {
	  alert("Error: Confirm Password cannot be blank!"); 
	  document.form1.txtRPwd.focus();
	  ok = false;
  	}
  	if(document.form1.txtPwd.value != document.form1.txtRPwd.value) {
 	alert("Password mismatch");
	document.form1.txtRPwd.focus();
	ok = false;
	}
  	return ok;
} 
  </script> 
  </head>
<body>
<div id="BodyWrapper">
    	<div id="Signin">
        <h2>Change Password</h2>
          <form name="form1" method="post" action="ch_pwd.php" onsubmit="return checkForm(this);">
          <table align="center">
          	<tr>
                <td align="left"><label "newpass" class="Signin_Label" >New Password:</label></td>
            </tr>
            <tr>
            	<td><input class="TextField" type="password" name="txtPwd" size="30" /></td>
            </tr>
            <tr>
                <td align="left"><label "re_type" class="Signin_Label">Re-Type New Password:</label></td>
            </tr>
            <tr>
            	<td><input class="TextField" type="password" name="txtRPwd" size="30" /></td>
            </tr>
            <tr>
            	<td align="right"><input type="submit" class="Signin_Button" value="Change Password"  /></td>
            </tr>
          </table>
          </form>
        </div>
    
</div>
<div id="Footer"></div>
</body>
</html>
