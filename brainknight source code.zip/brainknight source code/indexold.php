<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<link rel="stylesheet" type="text/css" href="style.css"/>
<title>Index</title>
</head>

<body>
	<div id="BodyWrapper">
    	<div id="TopStrip">Home | About Us | Contact Us</div>
        <div id="IndexContentWrapper">
        	<div id="Logo"><img src="images/logo1.png"/></div><div id="LogoImage"><img src="images/moneyhand2.png"/></div>
			<div class="Clearing"></div>
            <div class="IndexBlock"><h2>Welcome To the Site</h2><h3>A site where you can earn real money without deception, What you need to do is<br/><br/>
            => Sign up by clicking below on Left Side<br/><br/>
            => Sign in by clicking below on Right Side<br/><br/>
            => Start Tes choose best option and earn money</h3></div>
           <!-- <div class="IndexBlock"><h2>Feature 2</h2>Some Features. Some Features. Some Features. Some Features. Some Features.</div>
            <div class="IndexBlock"><h2>Feature 3</h2>Some Features. Some Features. Some Features. Some Features. Some Features.</div>
            <div class="IndexBlock"><h2>Feature 4</h2>Some Features. Some Features. Some Features. Some Features. Some Features.</div>-->
            <div class="Clearing"></div>
            <div class="EarnMoney"><img src="images/earnmoney.png"/></div>
            <div class="IndexSignup"><a href="sign_up.php">Sign Up</a></div><div class="IndexSignin"><a href="sign_in.php">Sign In</a></div>
            <div class="Clearing"></div>
        </div>
        <div id="Footer">Copyright 2013~14 all rights reserved.</div>
    </div>
</body>
</html>
