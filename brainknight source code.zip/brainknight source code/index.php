<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Brain Knight</title>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>

<body>
<div id="BodyWrapper">
	<div id="Header"></div>
   	<div id="Welcome">
    	<div class="Signin"><a href="sign_in.php">Login</a></div>
        <div class="Signup"><a href="sign_up.php">New Users Sign Up</a></div>
    </div>
    
</div>
<embed src="theme.mp3" hidden="true" autostart="true" loop="false" />
</body>
</html>