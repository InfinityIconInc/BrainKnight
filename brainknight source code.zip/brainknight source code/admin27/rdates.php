<?php
	include "data.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
<script language="javascript">
	function PrintIt ( ) {
		window.print() ;
	}
</script>
</head>

<body>
<?php
	mysql_select_db ( $database, $data);
	$sql = "SELECT DISTINCT (login_date) FROM user";
	$result = mysql_query ( $sql );
	echo ( "Select Date: <br />" );
	while ( $row = mysql_fetch_array ( $result ) ) {
		echo ( "<a href='rdates.php?ddate=" . $row ['login_date'] . "'>" . $row ['login_date'] . "</a> " );
	}
	
	if ( isset ( $_REQUEST['ddate'] ) ) {
?><br />

	<input type="button" value="Print" onclick="PrintIt();" />
<?
		$dt = $_REQUEST['ddate'];
		echo ( "<h1>Test Result (Dated: $dt)</h1>" );
		mysql_select_db ( $database, $data );
		$sqldt = "SELECT * FROM user WHERE login_date = '$dt'";

		$resultdt = mysql_query ( $sqldt );
		echo ( "<table border='1'>" );
		echo ( "<tr><th>UserName</th><th>Name</th><th>City</th><th>Phone</th><th>CNIC</th><th>EmpID</th><th>TQ</th><th>Correct</th><th>Wrong</th><th>%</th><th>Amount Earned</th></tr>" );
		while ( $rowdt = mysql_fetch_array ( $resultdt ) ) {
			$uidd = $rowdt['user_id'];
			echo ( "<tr><td>" . $rowdt['user_name'] . "</td><td>" . $rowdt['first_name'] . " " . $rowdt['last_name'] . "</td><td>" . $rowdt['city'] . "</td><td>" . $rowdt['phone_number'] . "</td><td>" . $rowdt['cnic_no'] . "</td><td>" . $rowdt['emp_id'] . "</td>" );
			$sqlcheck = "SELECT * FROM questions as q INNER JOIN answer_sheet as a ON q.q_id = a.q_id WHERE a.user_id = $uidd AND a.test_id = 1 AND q.q_ans1 = a.q_ans1 AND q.q_ans2 = a.q_ans2 AND q.q_ans3 = a.q_ans3 AND q.q_ans4 = a.q_ans4 AND q.q_ans5 = a.q_ans5 and a.test_date = '$dt'";
			//echo ( $sqlcheck );

			$totq = 30;
			$result2 = mysql_query ( $sqlcheck );
			$numrows = mysql_num_rows ( $result2 );
			$wrongq = $totq - $numrows;
			$amtearned = $numrows - ($wrongq * 2);
			echo "<td class='res_blo1'> $totq </td>";//totalquestions
			echo "<td class='res_blo1'>$numrows</td>";//correct ans
			echo "<td class='res_blo1'>$wrongq</td>";
			echo "<td class='res_blo1'>" . ($numrows / $totq)*100 . "%</td>";
			echo "<td class='res_blo1'>$amtearned.00 USD</td>";//amount earned
			echo "</tr>";
		}
		echo ( "</table>" );
	}
?>
</body>
</html>