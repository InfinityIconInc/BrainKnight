<?php
	session_start ( );
	if ( isset ( $_SESSION[ 'aid' ] ) ) {
		$_SESSION['aid'] = "";
		//unset ( $_SESSION[ 'aid'] );		
	}
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sign In</title>
</head>

<body>
<div id="Header"></div>
<center>
<h1>Admin Sign-in</h1>
<table border="0" align="center">
<form name="form1" method="post" action="admin_sign_in.php">
<tr><td>Admin Name:</td><td><input type="text" name="txtName" /></td></tr>
<tr><td>Password:</td><td><input type="password" name="txtPassword" /></td></tr>
<tr><td></td><td><input type="submit"value="Sign-in" /></td></tr>
</form>
</table>
</center>
</body>
</html>
