<?php require_once ( "data.php" ); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="description" content="For Editing Category"  />
<title>Edit Category</title>
</head>

<body>
<?php
	mysql_select_db ( $database, $data );
	$sql = "SELECT * FROM questions WHERE q_id =" . $_REQUEST['qid'];
	$result = mysql_query ( $sql );
	$row = mysql_fetch_assoc ( $result );

?>

<form name="form1" method="POST" action="edit_ques.php">
<table align="center" border="1">
<tr><td></td><td>Edit Question Form</td></tr>
<tr><td>Question ID:</td><td> <input type="text" name="txtQID" readonly="true" value="<?php echo ( $row [ 'q_id' ] ); ?>" /></td></tr>
<tr><td> Question:</td><td> <input type="text" name="txtQName" value="<?php echo ( $row [ 'q_ques' ] ); ?>" /></td></tr>
<tr><td>Option 1 </td><td><input type="text" name="txtopt1" value="<?php echo ( $row [ 'q_o1' ] ); ?>" /></td></tr>
<tr><td>Option 2 </td><td><input type="text" name="txtopt2" value="<?php echo ( $row [ 'q_o2' ] ); ?>" /></td></tr>
<tr><td>Option 3 </td><td><input type="text" name="txtopt3" value="<?php echo ( $row [ 'q_o3' ] ); ?>" /></td></tr>
<tr><td>Option 4 </td><td><input type="text" name="txtopt4" value="<?php echo ( $row [ 'q_o4' ] ); ?>" /></td></tr>
<tr><td>Answer 1 </td><td><input type="text" name="txtans1" value="<?php echo ( $row [ 'q_ans1' ] ); ?>" /></td></tr>
<tr><td>Answer 2 </td><td><input type="text" name="txtans2" value="<?php echo ( $row [ 'q_ans2' ] ); ?>" /></td></tr>
<tr><td>Answer 3 </td><td><input type="text" name="txtans3" value="<?php echo ( $row [ 'q_ans3' ] ); ?>" /></td></tr>
<tr><td>Answer 4 </td><td><input type="text" name="txtans4" value="<?php echo ( $row [ 'q_ans4' ] ); ?>" /></td></tr>

<tr><td></td><td><input type="submit" value="Edit Questions" /></td></tr>
</form>
<?php
	mysql_close ( $data );
?>
</table>
</body>
</html>
