<?php
	$host = "localhost";
	$database = "brain_knight";
	$username = "brain_uknight";
	$password = "Ojl99ems";
	$data = mysql_pconnect ( $host, $username, $password );
?>