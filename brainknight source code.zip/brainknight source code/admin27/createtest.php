<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<h1>Create Test</h1>
<form name="frmAddTest" id="frmAddTest" method="POST" action="addtest.php">
<table width="200" border="1">
  <tr>
    <td>Test Title</td>
    <td><label for="txtTitle"></label>
    <input type="text" name="txtTitle" id="txtTitle" /></td>
  </tr>
  <tr>
    <td>Description</td>
    <td>&nbsp;</td>
  </tr>
  <tr>
    <td>Start Date</td>
    <td><input type="text" name="txtTitle2" id="txtTitle2" /></td>
  </tr>
  <tr>
    <td>End Date</td>
    <td><input type="text" name="txtTitle3" id="txtTitle3" /></td>
  </tr>
  <tr>
    <td>Subject 1</td>
    <td><label for="ddlS1"></label>
      <select name="ddlS1" id="ddlS1">
    </select></td>
  </tr>
  <tr>
    <td>#ofQ</td>
    <td><input type="text" name="txtTitle4" id="txtTitle4" /></td>
  </tr>
  <tr>
    <td>Subject 2</td>
    <td><label for="ddlS1"></label>
      <select name="ddlS2" id="ddlS1">
    </select></td>
  </tr>
  <tr>
    <td># of Q</td>
    <td><input type="text" name="txtTitle5" id="txtTitle5" /></td>
  </tr>
  <tr>
    <td>Subject 3</td>
    <td><label for="ddlS1"></label>
      <select name="ddlS3" id="ddlS1">
    </select></td>
  </tr>
  <tr>
    <td># of Q</td>
    <td><input type="text" name="txtTitle6" id="txtTitle6" /></td>
  </tr>
  <tr>
    <td>Subject 4</td>
    <td><label for="ddlS1"></label>
      <select name="ddlS4" id="ddlS1">
    </select></td>
  </tr>
  <tr>
    <td># of Q</td>
    <td><input type="text" name="txtTitle7" id="txtTitle7" /></td>
  </tr>
  <tr>
    <td>Subject 5</td>
    <td><label for="ddlS1"></label>
      <select name="ddlS5" id="ddlS1">
    </select></td>
  </tr>
  <tr>
    <td># of Q</td>
    <td><input type="text" name="txtTitle8" id="txtTitle8" /></td>
  </tr>
  <tr>
    <td>&nbsp;</td>
    <td><input type="submit" value="Add Test"/></td>
  </tr>
</table>
</form>
<p>&nbsp;</p>
</body>
</html>