<?php require_once ( "data.php" );?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Add New Question</title>
</head>

<body>
<?php
	$ques = $_REQUEST[ 'txtQues' ];
	$opt1= $_REQUEST[ 'txtopt1'];
	$opt2= $_REQUEST[ 'txtopt2'];
	$opt3= $_REQUEST[ 'txtopt3'];
	$opt4= $_REQUEST[ 'txtopt4'];
	$ans1= $_REQUEST[ 'txtans1'];
	$ans2= $_REQUEST[ 'txtans2'];
	$ans3= $_REQUEST[ 'txtans3'];
	$ans4= $_REQUEST[ 'txtans4'];

	$ques = str_replace ("'", "`", $ques);
	$ques = str_replace ( "\"", "``", $ques );
	$opt1 = str_replace ("'", "`", $opt1 );
	$opt1 = str_replace ( "\"", "``", $opt1 );
	$opt2 = str_replace ("'", "`", $opt2 );
	$opt2 = str_replace ( "\"", "``", $opt2 );
	$opr3 = str_replace ("'", "`", $opt3 );
	$opt3 = str_replace ( "\"", "``", $opt3 );
	$opt4 = str_replace ("'", "`", $opt4);
	$opt4 = str_replace ( "\"", "``", $opt4 );

	
	$insert_sql = "INSERT INTO questions ( q_ques, q_o1, q_o2, q_o3, q_o4, q_ans1, q_ans2, q_ans3, q_ans4 ) VALUES ( '$ques', '$opt1', '$opt2', '$opt3', '$opt4', '$ans1', '$ans2', '$ans3', '$ans4' )";
	//echo ( $insert_sql );
	mysql_select_db ( $database, $data );
	if ( mysql_query ( $insert_sql, $data ) == 0 )
		echo ( "Could not Enter the Data" );
	else {
		echo ( "<h3>Record Entered</h3>" );
		echo ( "<a href='add_ques_form.php'>Click here to Add More Questions</a>");
?>
		<script language="javascript">
			alert ( "Record Entered" );
			setTimeout ( "location.href = 'add_ques_form.php'", 0);
		</script>
<?php
	}
	
		
	mysql_close ( $data );
?>
</body>
</html>
