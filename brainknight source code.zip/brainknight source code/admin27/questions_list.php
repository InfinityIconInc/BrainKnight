<?php require_once ( "data.php" );?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="description" content="Form For Listing Categories "  />
<title>List of Questions</title>
</head>

<body>
<div id="Header"></div>
<?php
	$sql = "SELECT * FROM questions;";
	mysql_select_db ( $database, $data );
	
	$result = mysql_query ( "SELECT * FROM questions", $data );
	$numofquest = mysql_num_rows ( $result );
	$recordsperpage = 10;
	$totalpages = $numofquest/$recordsperpage;
	$selectedpagenumber = 0;
	if ( isset ( $_REQUEST ['page'] ) )
		$selectedpagenumber = $_REQUEST['page'];

	$totalpages = ceil ( $totalpages );	
	for ( $i=0; $i<$totalpages; $i++ )
	{
		$j = $i + 1;
		echo ( "<a href='questions_list.php?page=$i'>" . $j . "</a> " );
	}
	$limitt = $selectedpagenumber * $recordsperpage;
	$resultq = mysql_query ( "SELECT * FROM questions ORDER BY q_id DESC LIMIT $limitt, $recordsperpage", $data );
	
	echo ( "<table align='center' border='1'>" );
	echo ( "<tr><th colspan='3'>Questions</th></tr>" );
	while ( $row = mysql_fetch_array ( $resultq ) )
	{
		echo ( "<tr>" );
		echo ( "<td>" );
		echo ( $row [ 'q_id' ] ).'&nbsp;&nbsp;';
		echo ( $row [ 'q_ques' ] . "<br/>" );
		echo ( $row [ 'q_o1' ]  . "<br/>");
		echo ( $row [ 'q_o2' ]  . "<br/>");
		echo ( $row [ 'q_o3' ]  . "<br/>");
		echo ( $row [ 'q_o4' ] ).  "<br/>";
		echo ( "Answer: <br />" );
        //echo ( $row [ 'q_ans1']);
        //echo ( $row [ 'q_ans2']);
		//echo ( $row [ 'q_ans3']);
        //echo ( $row [ 'q_ans4']);
 		if ( $row ['q_ans1'] == 1 )
			echo ( "Option Number 1" );
		if ( $row ['q_ans2'] == 1 )
			echo ( "Option Number 2" );
		if ( $row ['q_ans3'] == 1 )
			echo ( "Option Number 3" );
		if ( $row ['q_ans4'] == 1 )
			echo ( "Option Number 4" );

		echo ( "</td><td>" );
		echo ( "<a href='edit_ques_form.php?qid=" . $row [ 'q_id' ] . "'>Edit Question</a>" );
		echo("</td><td>");
		echo ( "<a href='delete_ques.php?qid=" . $row [ 'q_id' ] . "'>Delete Question</a>" );
		echo ( "</td>" );
		echo ( "</tr>" );
	}
	mysql_close ( $data );
?>
</table>
</body>
</html>
