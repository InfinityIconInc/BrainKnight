<html>
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
</head>
<body>
<center>
<div id="Header"></div>
<h1>BrainKnight Admin Panel</h1>
 <a href="r.php">View Result</a> | <a href="reset_email.php">Reset Email</a> | <a href="add_ques_form.php">Add Question</a> | <a href="questions_list.php">List of All Questions </a> | <a href="rdates.php"> Result</a>    
</center>
</body></html>
<br />