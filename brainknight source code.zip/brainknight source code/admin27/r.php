<?php
	include "data.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Results</title>
<script language="javascript">
	function GetResult ( ) {
		var uid = document.getElementById("ddlUsers").value;
		var xmlhttp = new XMLHttpRequest ( );
		xmlhttp.onreadystatechange = function ( ) {
			if  ( xmlhttp.readyState == 4 && xmlhttp.status == 200 ) {
				document.getElementById("ddlDate").style.display = "block";
				document.getElementById("ddlDate").innerHTML = xmlhttp.responseText;
				document.getElementById("cmdResult").style.display = "none";
				document.getElementById("cmdSubmit").style.display = "block";
			}
		}
		xmlhttp.open("GET", "get_test_dates.php?uid=" + uid);
		xmlhttp.send ( );
	}
</script>
</head>

<body>
<?php
		//////User First Last Name Form////////////////////
		mysql_select_db ( $database, $data );
		$sql = "SELECT * FROM user AS u INNER JOIN answer_sheet AS a ON u.user_id = a.user_id GROUP BY u.user_id;";
		$uresult = mysql_query ( $sql );
?>

		<form id='frmUN' method='GET' action='r.php'>
			<select id='ddlUsers' name='ddlUsers' class="TextField">
            <?php
			  while ( $urow = mysql_fetch_object ( $uresult ) ) {
				  echo ( "<option value='$urow->user_id'>" . ucwords ( $urow->first_name ) . " " . ucwords( $urow->last_name ) . "</option>" ); 
			  }
			?>
		</select>
        <select id="ddlDate" name="ddlDate" style="display: none;">
        </select>
        <input type="button" id="cmdResult" name="cmdResult" value="Get Test Taken Dates" onClick="GetResult ( );" />
        <input type="submit" id="cmdSubmit" name="cmdSubmit" value="Get Result" style="display: none;" />
		</form>
<?php
		//////Date of Test Area////////////////////////////
		if ( isset ( $_REQUEST [ 'ddlDate' ] ) ) {
			$datee = $_REQUEST ['ddlDate' ];
			$uidd = $_REQUEST [ 'ddlUsers' ];
			$sqlcheck = "SELECT * FROM questions as q INNER JOIN answer_sheet as a ON q.q_id = a.q_id WHERE a.user_id = $uidd AND a.test_id = 1 AND q.q_ans1 = a.q_ans1 AND q.q_ans2 = a.q_ans2 AND q.q_ans3 = a.q_ans3 AND q.q_ans4 = a.q_ans4 AND q.q_ans5 = a.q_ans5 and a.test_date = '$datee'";

			$totq = 30;
			$result2 = mysql_query ( $sqlcheck );
			$numrows = mysql_num_rows ( $result2 );
			$wrongq = $totq - $numrows;
			$amtearned = $numrows - ($wrongq * 2);
			echo ("<h1 align='center'>Quiz Result</h1>");		
			echo ("<div id='result'>");		
			echo ("<table align='center'>");
			echo ("<tr>");
			echo "<td class='res_blo'>Total Questions:</td><td class='res_blo1'> $totq </td></tr>";
			echo "<tr><td class='res_blo'>Correct Answers:</td><td class='res_blo1'>$numrows</td></tr>";
			echo "<tr><td class='res_blo'>Wrong Answers:</td><td class='res_blo1'>$wrongq</td></tr>";
			echo ("<tr><td class='res_blo'>Percentage: </td><td class='res_blo1'>" . ($numrows / $totq)*100 . "%</td></tr>" );
			echo "<tr><td class='res_blo'>Amount Earned:</td><td class='res_blo1'>$amtearned.00 USD</td></tr>";
			echo "</table>";
			echo "</div>";
		}
?>
</body>
</html>