<?php
	include "data.php";
	mysql_select_db ( $database, $data );
	$sqld = "SELECT * FROM answer_sheet WHERE user_id = " . $_REQUEST ['uid'] . " GROUP BY test_date";
	$resultd = mysql_query ( $sqld );
	while ( $rowd = mysql_fetch_object ( $resultd ) ) {
		echo ( "<option value='$rowd->test_date'>$rowd->test_date</option>" );
	}
?>