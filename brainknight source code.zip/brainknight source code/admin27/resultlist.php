<?php
	include "data.php";
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Untitled Document</title>
</head>

<body>
<table border="1">
<tr>
<th colspan="10" style="background: #000; color:#FFF">Test Results</th>
</tr>
<?php
		//////User First Last Name Form////////////////////
		mysql_select_db ( $database, $data );
		$sql = "SELECT * FROM user AS u INNER JOIN answer_sheet AS a ON u.user_id = a.user_id GROUP BY u.user_id;";
		$uresult = mysql_query ( $sql );
		

			  while ( $urow = mysql_fetch_object ( $uresult ) ) {
				  $uid = $urow->user_id;
				  echo ( "<tr><td colspan='3'>Name</td><td style='background: #ccc;' colspan='2'>" . ucwords ( $urow->first_name ) . " " . ucwords( $urow->last_name ) . "</td><td colspan='3'>Phone No.</td><td colspan='2' style='background: #ccc;'>$urow->phone_number</td></tr><tr><td colspan='3'>CNIC</td><td colspan='2' style='background: #ccc;'>$urow->cnic_no</td><td colspan='3'>Emp No.</td><td colspan='3' style='background: #ccc;'>$urow->emp_id</td></tr>" ); 
				  $sqld = "SELECT * FROM answer_sheet WHERE user_id = $uid GROUP BY test_date";
				  $resultd = mysql_query ( $sqld );
				  while ( $rowd = mysql_fetch_object ( $resultd ) ) {
					  echo ( "<tr><td colspan='10' align='center'>Test Date: " . $rowd->test_date . "</td></tr>" );
					  $sqlcheck = "SELECT * FROM questions as q INNER JOIN answer_sheet as a ON q.q_id = a.q_id WHERE a.user_id = $uid AND a.test_id = 1 AND q.q_ans1 = a.q_ans1 AND q.q_ans2 = a.q_ans2 AND q.q_ans3 = a.q_ans3 AND q.q_ans4 = a.q_ans4 AND q.q_ans5 = a.q_ans5 and a.test_date = '$rowd->test_date'";
		  
					  $totq = 30;
					  $result2 = mysql_query ( $sqlcheck );
					  $numrows = mysql_num_rows ( $result2 );
					  $wrongq = $totq - $numrows;
					  $amtearned = $numrows - ($wrongq * 2);
					  echo ("<tr>");
					  echo "<td>Total Questions</td><td style='background: #ccc;'> $totq</td>";
					  echo "<td>Correct Answers</td><td style='background: #ccc;'>$numrows</td>";
					  echo "<td>Wrong Answers</td><td style='background: #ccc;'>$wrongq</td>";
					  echo ("<td>Percentage</td><td style='background: #ccc;'>" . ($numrows / $totq)*100 . "%</td>" );
					  echo "<td>Amount Earned:</td><td style='background: #ccc;'>$amtearned.00 USD</td></tr>";
					  echo ( "<tr><td style='background: #000' colspan='10' align='center'>---</td></tr>" );
				  }
			  }
			?>

</table>
</body>
</html>