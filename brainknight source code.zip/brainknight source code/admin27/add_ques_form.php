<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>

<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<meta http-equiv="description" content="Form for Adding New Category"  />
<title>Add New Question</title>
<script language="javascript">
function verify(){ 
if(document.form1.txtQues.value=="") 
   { 
      alert("Plz enter your Question!"); 
      document.form1.txtQues.focus(); 
      return false; 
   }
   if(document.form1.txtopt1.value=="") 
   { 
      alert("Plz enter your Option1"); 
      document.form1.txtopt1.focus(); 
      return false; 
   }   
      if(document.form1.txtopt2.value=="") 
   { 
      alert("Plz enter your Option2"); 
      document.form1.txtopt2.focus(); 
      return false; 
   }   
   if(document.form1.txtopt3.value=="") 
   { 
      alert("Plz enter your option3"); 
      document.form1.txtopt3.focus(); 
      return false; 
   }   
   if(document.form1.txtopt4.value=="") 
   { 
      alert("Plz enter your option4"); 
      document.form1.txtopt4.focus(); 
      return false; 
   }   

	return true;
 }
</script> 
</head>

<body>
<div id="Header"></div>
<br/><br/><table align="center" border="1">
<form name="form1" method="POST" action="add_ques.php" onsubmit="return verify()">
<tr><td></td><td>Add Questions</td></tr>
<tr><td>Question:</td><td>   <textarea name="txtQues"></textarea></td></tr>
<tr><td>Option 1 </td><td><input type="text" name="txtopt1" /></td></tr>
<tr><td>Option 2 </td><td><input type="text" name="txtopt2" /></td></tr>
<tr><td>Option 3 </td><td><input type="text" name="txtopt3" /></td></tr>
<tr><td>Option 4 </td><td><input type="text" name="txtopt4" /></td></tr>
<tr><td>Answer 1 </td><td>
<select name="txtans1">
	<option value="1">Yes</option>
    <option value="0">No</option>
</select>
</td></tr>
<tr><td>Answer 2 </td><td><select name="txtans2">
	<option value="1">Yes</option>
    <option value="0">No</option>
</select>
</td></tr>
<tr><td>Answer 3 </td><td>
<select name="txtans3">
	<option value="1">Yes</option>
    <option value="0">No</option>
</select>
</td></tr>
<tr><td>Answer 4 </td><td>
<select name="txtans4">
	<option value="1">Yes</option>
    <option value="0">No</option>
</select>
</td></tr>
<tr><td align="center"></td><td><input type="submit" value="Add Question" /></td></tr>
</form>
</table>
</body>
</html>
