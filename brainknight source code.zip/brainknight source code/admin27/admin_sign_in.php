<?php
	session_start ( );
	require_once ( "data.php" );
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<meta http-equiv="Content-Type" content="text/html; charset=iso-8859-1" />
<title>Sign In</title>
</head>

<body>
<?php
$an=$_POST['txtName'];
$apw=$_POST['txtPassword'];
mysql_select_db ( $database, $data );
$sql="SELECT * FROM admin WHERE admin_name LIKE '$an' AND admin_password LIKE '$apw'";
$result=mysql_query($sql);
$nr=mysql_num_rows($result);
$row=mysql_fetch_object ( $result );
if ( $nr == 1 ) {
	echo ( "Welcome Admin" );
	$_SESSION['aid'] = $row->admin_id;
	echo ( "<script>location.href = 'admin_area.php';</script>" );
}
else
	echo ( "Invalid Login" );
?>
</body>
</html>
