<?php require_once ( "data.php" ); ?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml">
<head>
<link rel="stylesheet" type="text/css" href="style.css"/>

<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
<title>Reset Email</title>
</head>

<body>
<div id="Header"></div>

<?php
	mysql_select_db ( $database, $data );
	$sql = "UPDATE user SET login_date = '2014-1-1' WHERE user_id = 82 " ;
	$result = mysql_query ( $sql );
	
	if($result == 1)
	{
	   //echo "success";
	} 
		else
		{
			echo "fail";
			}
			


?>
<center>
<input type="submit" value="Reset Email" class="reset" /></div>
</center>
</html>