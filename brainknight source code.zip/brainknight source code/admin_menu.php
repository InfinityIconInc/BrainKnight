<center>
<h1>BrainKnight Admin Panel</h1>
<a href="add_question_form.php">Add Questions</a> | <a href="r.php">View Result</a> 
</center>
<br />